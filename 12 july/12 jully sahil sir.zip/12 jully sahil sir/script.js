// for (let i = 0; i < 10; i++) {
//   console.log(i);
// }
// console.log('Another action');

//fetch api returns a promise
const todos = fetch('https://jsonplaceholder.typicode.com/todos');

console.log('TCL: todos', todos);

